def filter_list(lst):
    return [item for item in lst if type(item) == int]