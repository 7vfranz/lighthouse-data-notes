def mean(digits):
    return sum([int(d) for d in str(digits)]) / len(str(digits))